package javaapplication38;

public class DefaultWords {
	public String dWord;
	public int weight;
	
	public DefaultWords(String dWord, int weight) {
		this.dWord = dWord;
		this.weight = weight;
	}
	
	public String toString(){
		return "[" + dWord + "," + weight + "]";
	}

}
