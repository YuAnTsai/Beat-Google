package javaapplication38;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vivi
 */
import java.util.*;
public class KeywordList {
private ArrayList<Node> list;
public KeywordList() {
	this.list=new ArrayList<Node>();
}

public void add(Node yt) {
ScoreCounter ScoreCounter = new ScoreCounter(yt);
	for (int i = 0; i < list.size(); i++) {
		Node keyword = list.get(i);
		ScoreCounter ScoreCounter2 = new ScoreCounter(keyword);
		if(keyword.title.equals(yt.title)){
            break;
        }
		if (ScoreCounter2.count(keyword) < ScoreCounter.count(yt)) {
			this.list.add(i, yt);
			return;
		}else if (ScoreCounter2.count(keyword) == ScoreCounter.count(yt)) {
			if (keyword.view < yt.view) {  		
			this.list.add(i, yt);
			return;
			}
		}
		}
	this.list.add(yt);
	}

public void output() {
	StringBuilder sb = new StringBuilder();
	for(int i =0;i <this.list.size();i++) {
		Node keyword = this.list.get(i);
		
		if(i>0) {
			sb.append(" ");
		}
		sb.append(keyword.toString());
	}
		System.out.println(sb.toString());
}

     
 
}


