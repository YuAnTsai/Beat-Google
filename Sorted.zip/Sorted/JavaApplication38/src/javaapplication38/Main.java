package javaapplication38;
import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import com.gargoylesoftware.htmlunit.*;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import java.io.IOException;
import java.util.*;
/* KeywordList ytlist=new KeywordList();
        ArrayList<String>array1=new ArrayList<String>();
        ArrayList<Node>yt=new ArrayList<Node>();
        //http://i.ytimg.com/vi/(please input your hash)/0.jpg
        Scanner sc=new Scanner(System.in);
        System.out.println("Please input your search keyword: ");
        String g=sc.nextLine();
        htmlfetcher gett=new htmlfetcher(g);
        KeywordList kyl=gett.gethtml();
        kyl.output();*/
public class Main {



      
      
    public static void main (String[] args) throws IOException {
         KeywordList ytlist=new KeywordList();
        ArrayList<String>array1=new ArrayList<String>();
        ArrayList<Node>yt=new ArrayList<Node>();
        //http://i.ytimg.com/vi/(please input your hash)/0.jpg
        Scanner sc=new Scanner(System.in);
        System.out.println("Please input your search keyword: ");
        String g=sc.nextLine();
        htmlfetcher gett=new htmlfetcher(g);
        KeywordList kyl=gett.gethtml();
        kyl.output();
   
}
            
}
       

        
    


            
      
       

        
    
