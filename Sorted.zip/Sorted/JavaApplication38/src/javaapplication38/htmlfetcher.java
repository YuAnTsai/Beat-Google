package javaapplication38;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import com.gargoylesoftware.htmlunit.*;
import com.gargoylesoftware.htmlunit.*;
import java.util.regex.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vivi
 */
public class htmlfetcher {
private String query;
private KeywordList ytlist=new KeywordList();
public htmlfetcher(String ky){this.query=ky;}
public String getquery(){return this.query;}
public KeywordList gethtml() throws IOException{    
        ArrayList<String>array1=new ArrayList<String>();
        
        ArrayList<Node>yt=new ArrayList<Node>();
        //http://i.ytimg.com/vi/(please input your hash)/0.jpg


        //search_query關鍵字->keyword為中文的話,出現keyword+搞笑狗
        if(query.getBytes().length!=query.length()){query=query+"+"+"搞笑狗";}
        //serch_query關鍵字->keyword為英文的話,出現keyword+funny dog videos
        else{query=query+"+funny+dog";}
        
        System.out.println(query);
        int count=1;
        String url   = "https://www.youtube.com/results?sp=CAMSAhgB&search_query="+query;
      while(true){
         if(count==40){
             
              break;
              }
          if(count!=1&&count<7){ url= array1.get(count-1); }
        /*因為c首頁只有2-6的原因
          所以出現此式
          */
         /* System.out.println("-"+url+" ");*/
         
          Document doc = Jsoup.connect(url).get();
            

       
             if(count>6){  
            for (Element a : doc.select(".yt-lockup-video")){
         /*   System.out.println("https://www.youtube.com"+a.attr("href") + " "+a.attr("title") );.yt-lockup-title > a[title] .attr("href")*/
            String pic=a.select("a[rel='spf-prefetch']").attr("href");pic = pic.replace("/watch?v=","http://i.ytimg.com/vi/");  
            pic=pic+"/0.jpg";
            String views=a.select("span").attr("aria-label");
            int s=views.indexOf("觀看次數：");
            if(views.length()!=0){
            char aa=(views.charAt(views.length()-1));
            String st=Character.toString(aa);
            views=views.replace("觀看次數：","");
            if((st.contains("次"))){views=views.substring(s,views.length()-1);}
            views=views.trim();
            String str2="";
            if(views != null && !"".equals(views)){
            for(int i=0;i<views.length();i++){
            if(views.charAt(i)>=48 && views.charAt(i)<=57){
            str2+=views.charAt(i);
            }
            }}

            views=str2.replace(",", "");
            views=views.replace(" ", "");}
            int view;
            if(views!=""){view=Integer.parseInt(views);}else{ view=0;}
            
            ytlist.add(new Node("https://www.youtube.com"+a.select("a[rel='spf-prefetch']").attr("href"),a.select("a[rel='spf-prefetch']").attr("title"),pic,view));
            }
           
           count++; }
          if(count==1){
            /*第一次 ,並把2-6頁加入*/
             for (Element a : doc.select(".yt-lockup-video")){
         /*   System.out.println("https://www.youtube.com"+a.attr("href") + " "+a.attr("title") );.yt-lockup-title > a[title] .attr("href")*/

            String pic=a.select("a[rel='spf-prefetch']").attr("href");pic = pic.replace("/watch?v=","http://i.ytimg.com/vi/");  
            pic=pic+"/0.jpg";
            String views=a.select("span").attr("aria-label");
            int s=views.indexOf("觀看次數：");
            if(views.length()!=0){
            char aa=(views.charAt(views.length()-1));
            
            String st=Character.toString(aa);
            views=views.replace("觀看次數：","");
            if((st.contains("次"))){views=views.substring(s,views.length()-1);}
            views=views.trim();
            String str2="";
            if(views != null && !"".equals(views)){
            for(int i=0;i<views.length();i++){
            if(views.charAt(i)>=48 && views.charAt(i)<=57){
            str2+=views.charAt(i);
            }
            }}
            

            views=str2.replace(",", "");
            views=views.replace(" ", "");}
            int view;
            if(views!=""){view=Integer.parseInt(views);}else{ view=0;}
            
            ytlist.add(new Node("https://www.youtube.com"+a.select("a[rel='spf-prefetch']").attr("href"),a.select("a[rel='spf-prefetch']").attr("title"),pic,view));
            
            }
            for (Element a : doc.select("a")) {
           /* System.out.println("https://www.youtube.com"+a.attr("href") + " "+a.attr("aria-label") ); String pic=a.attr("href");pic = pic.replace("/watch?v=","http://i.ytimg.com/vi/");  
            pic=pic+"/0.jpg";*/
           
           /* System.out.println(pic);*/
            if(a.attr("aria-label").contains("前往")){
                String o="https://www.youtube.com"+(a.attr("href"));      
                        array1.add(o);
            }
            
        }
            if(array1.size()==0){break;}
        }
          if(array1.size()!=0&&count<7){
             /*分析每一頁,  
              */
            for (Element a : doc.select(".yt-lockup-video")){
         /*   System.out.println("https://www.youtube.com"+a.attr("href") + " "+a.attr("title") );.yt-lockup-title > a[title] .attr("href")*/

            String pic=a.select("a[rel='spf-prefetch']").attr("href");pic = pic.replace("/watch?v=","http://i.ytimg.com/vi/");  
            pic=pic+"/0.jpg";
            String views=a.select("span").attr("aria-label");
            int s=views.indexOf("觀看次數：");
            if(views.length()!=0){
            char aa=(views.charAt(views.length()-1));
            views=views.replace("觀看次數：","");
            String st=Character.toString(aa);
            if((st.contains("次"))){views=views.substring(s,views.length()-1);}
            views=views.trim();
            String str2="";
            if(views != null && !"".equals(views)){
            for(int i=0;i<views.length();i++){
            if(views.charAt(i)>=48 && views.charAt(i)<=57){
            str2+=views.charAt(i);
            }
            }}

            views=str2.replace(",", "");
            views=views.replace(" ", "");}
            int view;
            if(views!=""){view=Integer.parseInt(views);}else{ view=0;}
            ytlist.add(new Node("https://www.youtube.com"+a.select("a[rel='spf-prefetch']").attr("href"),a.select("a[rel='spf-prefetch']").attr("title"),pic,view));
            
            }
           
                count++;
                continue;             
            }if(count>7){
            String check="前往第 "+count+" 頁";
            for (Element a : doc.select("a")){
            if(a.attr("aria-label").contains(check)){
                System.out.println(check);
                String o="https://www.youtube.com"+(a.attr("href"));
                url=o;break;}
        }
            continue;}              
          }return ytlist;
    
}
     }
