/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication38;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Vivi
 */
public class ScoreCounter {
	private ArrayList<DefaultWords> weightWords = new ArrayList<DefaultWords>(Arrays.asList(
			new DefaultWords("dog",5), new DefaultWords("funniest",4), new DefaultWords("hilarious",4),
			new DefaultWords("laugh",4), new DefaultWords("tease",4), new DefaultWords("fail",3),
			new DefaultWords("husky",3), new DefaultWords("corgi",3), new DefaultWords("ultimate",2),
			new DefaultWords("compilation",2),
			new DefaultWords("狗",5), new DefaultWords("好笑",4), new DefaultWords("搞笑",4),
			new DefaultWords("笑爛",4), new DefaultWords("逗",4), new DefaultWords("失誤",3),
			new DefaultWords("哈士奇",3), new DefaultWords("柯基",3),new DefaultWords("合集",2)
			
			));
	
	
    public ScoreCounter(Node node) {
    	count(node);
    }
    
    public int count(Node node){
    	String nodeTitle = node.title;
    	nodeTitle = nodeTitle.toLowerCase();
    	
    	int sum = 0;
    	for(int i  = 0; i < weightWords.size(); i++){
    		String str = weightWords.get(i).dWord;
    		int weight = weightWords.get(i).weight;
    		
    		if(nodeTitle.indexOf(str) != -1){
    			sum = sum + weight;
    		}
    		
    	}
    	
    	
    	return 0;
    }
    
}
