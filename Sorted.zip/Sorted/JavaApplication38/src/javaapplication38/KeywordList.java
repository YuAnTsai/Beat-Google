package javaapplication38;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vivi
 */
import java.util.*;
public class KeywordList {
private ArrayList<Node> list;
public KeywordList() {
	this.list=new ArrayList<Node>();
}
public void add(Node yt) {
	if(list.size()>=25){
	    for(int j=list.size()-25;j<list.size();j++){
	        Node keyword = list.get(j);        
	        if(keyword.title.equals(yt.title)){
	            break;
	        }
	        if(j==list.size()-1){
	        	for (int i = 0; i < list.size(); i++) {
	        		Node keyword = list.get(i);
	        		if (yt.count < keyword.count) {
	        			this.list.add(i, yt);
	        			return;
	        		}else if (yt.count == keyword.count){
	        			if (yt.view < keyword.view) {
	        				this.list.add(i, yt);
	        				return;
	        			}
	        			this.list.add(yt);
	        		}
	        		this.list.add(yt);
	        		}
	        }
	    }
	}else{
		for (int i = 0; i < list.size(); i++) {
    		Node keyword = list.get(i);
    		if (yt.count < keyword.count) {
    			this.list.add(i, yt);
    			return;
    		}else if (yt.count == keyword.count) {
    			if (yt.view < keyword.view) {  		
    			this.list.add(i, yt);
    			return;
    			}
    			this.list.add(yt);
    		}
    		this.list.add(yt);
    		}
		}
	}

public void output() {
	StringBuilder sb = new StringBuilder();
	for(int i =0;i <this.list.size();i++) {
		Node keyword = this.list.get(i);
		
		if(i>0) {
			sb.append(" ");
		}
		sb.append(keyword.toString());
	}
		System.out.println(sb.toString());
}

     
 
}


