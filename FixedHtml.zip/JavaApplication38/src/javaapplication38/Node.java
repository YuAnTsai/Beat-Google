package javaapplication38;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vivi
 */
public class Node{
    public String youtubeURL;
    public String title;
    public String pic;
    public int view;
    public Node(){
    this.youtubeURL=youtubeURL;
    this.title=title;
    this.pic=pic;
    this.view=view;
}
    public Node(String youtubeURL,String title,String pic,int view){
    this.youtubeURL=youtubeURL;
    this.title=title;
    this.pic=pic;
    this.view=view;
     }

public String toString(){
   return "["+youtubeURL+","+title+","+ pic+","+view+"]"+"\n";
}
@Override
public boolean equals(Object obj) {
if(obj == null) return false;
if(this == obj) return true;
if(obj instanceof Node){ 
Node user =(Node)obj;
//			if(user.id = this.id) return true; // 只比較id
// 比較id和username 一致時才返回true 之後再去比較 hashCode
if(user.youtubeURL == this.youtubeURL && user.title.equals(this.title)) return true;
}
return false;
}
/**
* 重寫hashcode 方法，返回的hashCode 不一樣才認定為不同的物件
*/
@Override
public int hashCode() {
//		return id.hashCode(); // 只比較id，id一樣就不新增進集合
return youtubeURL.hashCode() * title.hashCode();
}
}

