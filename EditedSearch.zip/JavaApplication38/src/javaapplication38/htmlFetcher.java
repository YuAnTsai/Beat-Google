package javaapplication38;
import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import com.gargoylesoftware.htmlunit.*;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import java.io.IOException;
import java.util.*;

public class htmlFetcher {

    public static void main (String[] args) throws IOException {
        KeywordList ytlist=new KeywordList();
        ArrayList<String>array1=new ArrayList<String>();
        ArrayList<Node>yt=new ArrayList<Node>();
        //http://i.ytimg.com/vi/(please input your hash)/0.jpg
        Scanner sc=new Scanner(System.in);
        System.out.println("Please input your search keyword: ");
        String query = sc.nextLine();
        //search_query關鍵字->keyword為中文的話,出現keyword+搞笑狗
        if(query.getBytes().length!=query.length()){query=query+"+"+"搞笑狗";}
        //serch_query關鍵字->keyword為中文的話,出現keyword+funny dog videos
        else{query=query+"+funny+dog+videos";}
        
        System.out.println(query);
        int count=1;
        String url   = "https://www.youtube.com/results?sp=CAMSAhgB&search_query="+query;
      while(true){
         if(count==30){
              break;
              }
          if(count!=1&&count<7){ url= array1.get(count-1); }
        /*因為c首頁只有2-6的原因
          所以出現此式
          */
         /* System.out.println("-"+url+" ");*/
         
          Document doc = Jsoup.connect(url).get();
            

       
             if(count>6){  
            for (Element a : doc.select(".yt-lockup-video")){
         /*   System.out.println("https://www.youtube.com"+a.attr("href") + " "+a.attr("title") );.yt-lockup-title > a[title] .attr("href")*/
            String pic=a.select("a[rel='spf-prefetch']").attr("href");pic = pic.replace("/watch?v=","http://i.ytimg.com/vi/");  
            pic=pic+"/0.jpg";
            String views=a.select("span").attr("aria-label");
            int s=views.indexOf("觀");
            views=views.substring(s);
            ytlist.add(new Node("https://www.youtube.com"+a.select("a[rel='spf-prefetch']").attr("href"),a.select("a[rel='spf-prefetch']").attr("title"),pic,views));
            }
           
           count++; }
          if(count==1){
            /*第一次 ,並把2-6頁加入*/
             for (Element a : doc.select(".yt-lockup-video")){
         /*   System.out.println("https://www.youtube.com"+a.attr("href") + " "+a.attr("title") );.yt-lockup-title > a[title] .attr("href")*/

            String pic=a.select("a[rel='spf-prefetch']").attr("href");pic = pic.replace("/watch?v=","http://i.ytimg.com/vi/");  
            pic=pic+"/0.jpg";
            String views=a.select("span").attr("aria-label");
            int s=views.indexOf("觀");
            views=views.substring(s);
            ytlist.add(new Node("https://www.youtube.com"+a.select("a[rel='spf-prefetch']").attr("href"),a.select("a[rel='spf-prefetch']").attr("title"),pic,views));
            
            }
            for (Element a : doc.select("a")) {
           /* System.out.println("https://www.youtube.com"+a.attr("href") + " "+a.attr("aria-label") ); String pic=a.attr("href");pic = pic.replace("/watch?v=","http://i.ytimg.com/vi/");  
            pic=pic+"/0.jpg";*/
           
           /* System.out.println(pic);*/
            if(a.attr("aria-label").contains("前往")){
                String o="https://www.youtube.com"+(a.attr("href"));      
                        array1.add(o);
            }
            
        }
            if(array1.size()==0){break;}
        }
          if(array1.size()!=0&&count<7){
             /*分析每一頁,  
              */
            for (Element a : doc.select(".yt-lockup-video")){
         /*   System.out.println("https://www.youtube.com"+a.attr("href") + " "+a.attr("title") );.yt-lockup-title > a[title] .attr("href")*/

            String pic=a.select("a[rel='spf-prefetch']").attr("href");pic = pic.replace("/watch?v=","http://i.ytimg.com/vi/");  
            pic=pic+"/0.jpg";
            String views=a.select("span").attr("aria-label");
            int s=views.indexOf("觀");
            views=views.substring(s);
            ytlist.add(new Node("https://www.youtube.com"+a.select("a[rel='spf-prefetch']").attr("href"),a.select("a[rel='spf-prefetch']").attr("title"),pic,views));
            
            }
           
                count++;
                continue;             
            }if(count>7){
            String check="前往第 "+count+" 頁";
            for (Element a : doc.select("a")){
            if(a.attr("aria-label").contains(check)){
                System.out.println(check);
                String o="https://www.youtube.com"+(a.attr("href"));
                url=o;break;}
        }
            continue;}              
          }
      ytlist.output();
 
    
    }
   
}
            
      
       

        
    
